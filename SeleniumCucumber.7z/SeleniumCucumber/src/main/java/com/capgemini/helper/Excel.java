package com.capgemini.helper;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel {

	FileInputStream file;
	XSSFWorkbook workbook;
	XSSFSheet sheet;
	

	public String readData (int row, int column ) {
		try {
			System.out.println("\n---In Excel readData() try---\n");
			file = new FileInputStream(new File("../SeleniumCucumber/src/main/java/com/capgemini/Assets/ConferenceRoom.xlsx"));
			workbook = new XSSFWorkbook(file);
		
			
		}
		catch (Exception e){
			System.out.println("\n---In Excel readData() catch---\n");
			e.printStackTrace();			        
		}
		finally {
			System.out.println("\n---In Excel readData() finally---\n");
		}
		sheet = workbook.getSheetAt(0);
		
		XSSFCell cell = sheet.getRow(row).getCell(column);
		DataFormatter df = new DataFormatter();
		String value = df.formatCellValue(cell);
		
	    return value;
	}
}
