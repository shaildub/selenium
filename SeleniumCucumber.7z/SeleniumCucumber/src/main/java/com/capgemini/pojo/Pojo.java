package com.capgemini.pojo;

public class Pojo {

	private String FirstName;
	private String LastName;
	private String Email;
	private Long ContactNo;
	private Integer NumberOfPeopleAttending;
	private String Address;
	private String BuildingName;
	private String AreaName;
	private String City;
	private String State;
	private String member;
	
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public Long getContactNo() {
		return ContactNo;
	}
	public void setContactNo(Long contactNo) {
		ContactNo = contactNo;
	}
	public Integer getNumberOfPeopleAttending() {
		return NumberOfPeopleAttending;
	}
	public void setNumberOfPeopleAttending(Integer numberOfPeopleAttending) {
		NumberOfPeopleAttending = numberOfPeopleAttending;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getBuildingName() {
		return BuildingName;
	}
	public void setBuildingName(String buildingName) {
		BuildingName = buildingName;
	}
	public String getAreaName() {
		return AreaName;
	}
	public void setAreaName(String areaName) {
		AreaName = areaName;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getMember() {
		return member;
	}
	public void setMember(String member) {
		this.member = member;
	}
	
}
