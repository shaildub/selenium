package com.capgemini.Test;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.capgemini.helper.Excel;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MethodsTest {
	
	Excel  e = new Excel();

	public String url = "http://localhost:9999/SeleniumCucumber/ConferenceRegistartion.html";
	WebDriver driver;
	WebElement next;
	WebElement pay;

	@Before
	public void pre() {
		System.out.println("\n---In Methods pre()---\n");
		System.setProperty("webdriver.chrome.driver", "D:\\_shaily\\spring_selenium\\" + "chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(url);
	}

	@Test
	public void TestAll() throws InterruptedException {
		System.out.println("\n---In Methods TestAll() Start---\n");
		for(int i=1; i<=3; i++ ) {
			System.out.println("Start with " + driver.getTitle());
			i_am_on_conference_registration_page();
			i_click_on_Next_link_without_filling_First_Name();
			a_message_Please_fill_the_First_Name_should_be_displayed(e.readData(i, 0));
			i_click_on_Next_link_without_filling_Last_Name();
			a_message_Please_fill_the_Last_Name_should_be_displayed(e.readData(i, 1));
			i_click_on_Next_link_without_filling_Email();
			a_message_Please_fill_the_Email_should_be_displayed(e.readData(i, 2));
//			i_click_on_Next_link_without_filling_valid_Email();
//			a_message_Please_enter_valid_Email_Id_should_be_displayed(e.readData(i, 2));
			i_click_on_Next_link_without_filling_Contact_no();
			a_message_Please_fill_the_Contact_No_should_be_displayed(e.readData(i, 3));
//			i_click_on_Next_link_without_filling_valid_Contact_no();
//			a_message_Please_enter_valid_Contact_no_should_be_displayed(e.readData(i, 3));
			i_click_on_Next_link_without_filling_Number_of_people_attending();
			a_message_Please_fill_the_Number_of_people_attending_should_be_displayed(e.readData(i, 4));
			i_click_on_Next_link_without_filling_Building_Name_Room_No();
			a_message_Please_fill_the_Building_Room_No_should_be_displayed(e.readData(i, 5));
			i_click_on_Next_link_without_filling_Area_Name();
			a_message_Please_fill_the_Area_name_should_be_displayed(e.readData(i, 6));
			i_click_on_Next_link_without_filling_City();
			a_message_Please_select_city_should_be_displayed(e.readData(i, 7));
			i_click_on_Next_link_without_filling_State();
			a_message_Please_select_state_should_be_displayed(e.readData(i, 8));
			i_click_on_Next_link_without_filling_MemeberShip_status();
			for(int j=9; j<=10; j++) {	
				String check = e.readData(i, j);
				if(check.equalsIgnoreCase("Yes")) {
					a_message_Please_Select_MemeberShip_status_should_be_displayed(j);
					j++;
					break; 
				}				
			} 
			i_click_on_Next_link_after_sending_all_valid_data();
			Thread.sleep(2000);
			a_message_Personal_Details_are_validated_should_be_displayed();
			System.out.println("Switch to " + driver.getTitle());
			i_am_on_payment_details_page();
			i_do_not_fill_Card_Holder_Name_and_I_click_on_Make_Payment_button();
			a_message_Please_fill_the_Card_holder_name_should_be_displayed();
			i_do_not_fill_Debit_Card_Number_and_I_click_on_Make_Payment_button();
			a_message_Please_fill_the_Debit_card_Number_should_be_displayed();
			i_do_not_fill_CVV_and_I_click_on_Make_Payment_button();
			a_message_Please_fill_the_CVV_should_be_displayed();
			i_fill_incorrect_Expiration_month_and_I_click_on_Make_Payment_button();
			a_message_Please_fill_expiration_month_should_be_displayed();
			i_do_not_fill_Expiration_Year_and_I_click_on_Make_Payment_button();
			a_message_Please_fill_the_expiration_year_should_be_displayed();
			i_click_on_Make_Payment_button_after_entering_all_valid_details();
			Thread.sleep(2000);
			a_message_Conference_Room_Booking_successfully_done_should_be_displayed();
			System.out.println("End with " + driver.getTitle());
			Thread.sleep(2000);
			driver.navigate().to(url);
		}
		System.out.println("\n---In Methods TestAll() End---\n");
	}

	@After
	public void post() {
		System.out.println("\n---In Methods post()---\n");
		driver.close();
		driver.quit();
	}

//	On Conference Registration page
	
	@Given("^I am on conference registration page$")
	public void i_am_on_conference_registration_page() {
		System.out.println("ON CR");
		assertEquals("Conference Registration", driver.getTitle());
		next = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
	}

	@When("^I click on 'Next' link without filling 'First Name'$")
	public void i_click_on_Next_link_without_filling_First_Name() {
		System.out.println("FILL FN next");
		next.click();
	}

	@Then("^A message 'Please fill the First Name' should be displayed$")
	public void a_message_Please_fill_the_First_Name_should_be_displayed(String data) {
		System.out.println("FILL FN");
		assertEquals("Please fill the First Name", driver.switchTo().alert().getText());
		driver.switchTo().alert().dismiss();
		WebElement el = driver.findElement(By.id("txtFirstName"));
		el.sendKeys(data);
	}

	@When("^I click on 'Next' link without filling 'Last Name'$")
	public void i_click_on_Next_link_without_filling_Last_Name() {
		System.out.println("FILL LN next");
		next.click();
	}

	@Then("^A message 'Please fill the Last Name' should be displayed$")
	public void a_message_Please_fill_the_Last_Name_should_be_displayed(String data) {
		System.out.println("FILL LN");
		assertEquals("Please fill the Last Name", driver.switchTo().alert().getText());
		driver.switchTo().alert().dismiss();
		WebElement el = driver.findElement(By.id("txtLastName"));
		el.sendKeys(data);
	}

	@When("^I click on 'Next' link without filling 'Email'$")
	public void i_click_on_Next_link_without_filling_Email() {
		System.out.println("FILL EM next");
		next.click();
	}

	@Then("^A message 'Please fill the Email' should be displayed$")
	public void a_message_Please_fill_the_Email_should_be_displayed(String data) {
		System.out.println("FILL EM");
		assertEquals("Please fill the Email", driver.switchTo().alert().getText());
		driver.switchTo().alert().dismiss();
		WebElement el = driver.findElement(By.id("txtEmail"));
		el.sendKeys(data);
	}

	@When("^I click on 'Next' link without filling valid 'Email'$")
	public void i_click_on_Next_link_without_filling_valid_Email() {
		System.out.println("VALI EM next");
		next.click();
	}

	@Then("^A message 'Please enter valid Email Id' should be displayed$")
	public void a_message_Please_enter_valid_Email_Id_should_be_displayed(String data) {
		System.out.println("VALI EM");
		assertEquals("Please enter valid Email Id.", driver.switchTo().alert().getText());
		driver.switchTo().alert().dismiss();
		WebElement el = driver.findElement(By.id("txtEmail"));
		el.clear();
		el.sendKeys(data);
	}

	@When("^I click on 'Next' link without filling 'Contact no\\.'$")
	public void i_click_on_Next_link_without_filling_Contact_no() {
		System.out.println("FILL CN next");
		next.click();
	}

	@Then("^A message 'Please fill the Contact No\\.' should be displayed$")
	public void a_message_Please_fill_the_Contact_No_should_be_displayed(String data) {
		System.out.println("FILL CN");
		assertEquals("Please fill the Contact No.", driver.switchTo().alert().getText());
		driver.switchTo().alert().dismiss();
		WebElement el = driver.findElement(By.id("txtPhone"));
		el.sendKeys(data);
	}

	@When("^I click on 'Next' link without filling valid 'Contact no\\.'$")
	public void i_click_on_Next_link_without_filling_valid_Contact_no() {
		System.out.println("VALI CN next");
		next.click();
	}

	@Then("^A message 'Please enter valid Contact no\\.' should be displayed$")
	public void a_message_Please_enter_valid_Contact_no_should_be_displayed(String data) {
		System.out.println("VALI CN");
		assertEquals("Please enter valid Contact no.", driver.switchTo().alert().getText());
		driver.switchTo().alert().dismiss();
		WebElement el = driver.findElement(By.id("txtPhone"));
		el.clear();
		el.sendKeys(data);
	}

	@When("^I click on 'Next' link without filling 'Number of people attending'$")
	public void i_click_on_Next_link_without_filling_Number_of_people_attending() {
		System.out.println("FILL NP next");
		next.click();
	}

	@Then("^A message 'Please fill the Number of people attending' should be displayed$")
	public void a_message_Please_fill_the_Number_of_people_attending_should_be_displayed(String data) {
		System.out.println("FILL NP");
		assertEquals("Please fill the Number of people attending", driver.switchTo().alert().getText());
		driver.switchTo().alert().dismiss();
		Select el = new Select(driver.findElement(By.name("size")));
		el.selectByVisibleText(data);
	}

	@When("^I click on 'Next' link without filling 'Building Name & Room No'$")
	public void i_click_on_Next_link_without_filling_Building_Name_Room_No() {
		System.out.println("FILL BN next");
		next.click();
	}

	@Then("^A message 'Please fill the Building & Room No' should be displayed$")
	public void a_message_Please_fill_the_Building_Room_No_should_be_displayed(String data) {
		System.out.println("FILL BN");
		assertEquals("Please fill the Building & Room No", driver.switchTo().alert().getText());
		driver.switchTo().alert().dismiss();
		WebElement el = driver.findElement(By.id("txtAddress1"));
		el.sendKeys(data);
	}

	@When("^I click on 'Next' link without filling 'Area Name'$")
	public void i_click_on_Next_link_without_filling_Area_Name() {
		System.out.println("FILL AN next");
		next.click();
	}

	@Then("^A message 'Please fill the Area name' should be displayed$")
	public void a_message_Please_fill_the_Area_name_should_be_displayed(String data) {
		System.out.println("FILL AN");
		assertEquals("Please fill the Area name", driver.switchTo().alert().getText());
		driver.switchTo().alert().dismiss();
		WebElement el = driver.findElement(By.id("txtAddress2"));
		el.sendKeys(data);
	}

	@When("^I click on 'Next' link without filling 'City'$")
	public void i_click_on_Next_link_without_filling_City() {
		System.out.println("FILL CN next");
		next.click();
	}

	@Then("^A message 'Please select city' should be displayed$")
	public void a_message_Please_select_city_should_be_displayed(String data) {
		System.out.println("FILL CN");
		assertEquals("Please select city", driver.switchTo().alert().getText());
		driver.switchTo().alert().dismiss();
		Select el = new Select(driver.findElement(By.name("city")));
		el.selectByValue(data);
	}

	@When("^I click on 'Next' link without filling 'State'$")
	public void i_click_on_Next_link_without_filling_State() {
		System.out.println("FILL SN next");
		next.click();
	}

	@Then("^A message 'Please select state' should be displayed$")
	public void a_message_Please_select_state_should_be_displayed(String data) {
		System.out.println("FILL SN");
		assertEquals("Please select state", driver.switchTo().alert().getText());
		driver.switchTo().alert().dismiss();
		Select el = new Select(driver.findElement(By.name("state")));
		el.selectByValue("Telangana");
	}

	@When("^I click on 'Next' link without filling 'MemeberShip status'$")
	public void i_click_on_Next_link_without_filling_MemeberShip_status() {
		System.out.println("FILL MS next");
		next.click();
	}

	@Then("^A message 'Please Select MemeberShip status' should be displayed$")
	public void a_message_Please_Select_MemeberShip_status_should_be_displayed(Integer i) {
		System.out.println("FILL MS");
		assertEquals("Please Select MemeberShip status", driver.switchTo().alert().getText());
		driver.switchTo().alert().dismiss();
		if(i==9) {
			WebElement el1 = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[12]/td[2]/input"));
			el1.click();
		}
		else {
			WebElement el2 = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[13]/td[2]/input"));
			el2.click();
		}
	}

	@When("^I click on 'Next' link after sending all valid data$")
	public void i_click_on_Next_link_after_sending_all_valid_data() {
		System.out.println("next");
		next.click();
	}

	@Then("^A message 'Personal Details are validated\\.' should be displayed$")
	public void a_message_Personal_Details_are_validated_should_be_displayed() {
		assertEquals("Personal details are validated.", driver.switchTo().alert().getText());
		driver.switchTo().alert().dismiss();
	}
	
//	On Payment Details page
	
	@Given("^I am on payment details page$")
	public void i_am_on_payment_details_page() {
		assertEquals(driver.getTitle(), "Payment Details");
		pay = driver.findElement(By.id("btnPayment"));
	}

	@When("^I do not fill 'Card Holder Name' and I click on 'Make Payment' button$")
	public void i_do_not_fill_Card_Holder_Name_and_I_click_on_Make_Payment_button() {
		pay.click();
	}

	@Then("^A message 'Please fill the Card holder name' should be displayed$")
	public void a_message_Please_fill_the_Card_holder_name_should_be_displayed() {
		assertEquals("Please fill the Card holder name", driver.switchTo().alert().getText());
		driver.switchTo().alert().dismiss();
		WebElement el = driver.findElement(By.id("txtCardholderName"));
		el.sendKeys("Shaily Dubey");
	}

	@When("^I do not fill 'Debit Card Number' and I click on 'Make Payment' button$")
	public void i_do_not_fill_Debit_Card_Number_and_I_click_on_Make_Payment_button() {
		pay.click();
	}

	@Then("^A message 'Please fill the Debit card Number' should be displayed$")
	public void a_message_Please_fill_the_Debit_card_Number_should_be_displayed() {
		assertEquals("Please fill the Debit card Number", driver.switchTo().alert().getText());
		driver.switchTo().alert().dismiss();
		WebElement el = driver.findElement(By.id("txtDebit"));
		el.sendKeys("789654123014");
	}

	@When("^I do not fill 'CVV' and I click on 'Make Payment' button$")
	public void i_do_not_fill_CVV_and_I_click_on_Make_Payment_button() {
		pay.click();
	}

	@Then("^A message 'Please fill the CVV' should be displayed$")
	public void a_message_Please_fill_the_CVV_should_be_displayed() {
		assertEquals("Please fill the CVV", driver.switchTo().alert().getText());
		driver.switchTo().alert().dismiss();
		WebElement el = driver.findElement(By.id("txtCvv"));
		el.sendKeys("956");
	}

	@When("^I fill incorrect 'Expiration month' and I click on 'Make Payment' button$")
	public void i_fill_incorrect_Expiration_month_and_I_click_on_Make_Payment_button() {
		pay.click();
	}

	@Then("^A message 'Please fill expiration month' should be displayed$")
	public void a_message_Please_fill_expiration_month_should_be_displayed() {
		assertEquals("Please fill expiration month", driver.switchTo().alert().getText());
		driver.switchTo().alert().dismiss();
		WebElement el = driver.findElement(By.id("txtMonth"));
		el.sendKeys("11");
	}

	@When("^I do not fill 'Expiration Year' and I click on 'Make Payment' button$")
	public void i_do_not_fill_Expiration_Year_and_I_click_on_Make_Payment_button() {
		pay.click();
	}

	@Then("^A message 'Please fill the expiration year' should be displayed$")
	public void a_message_Please_fill_the_expiration_year_should_be_displayed() {
		assertEquals("Please fill the expiration year", driver.switchTo().alert().getText());
		driver.switchTo().alert().dismiss();
		WebElement el = driver.findElement(By.id("txtYear"));
		el.sendKeys("2022");
	}

	@When("^I click on 'Make Payment' button after entering all valid details$")
	public void i_click_on_Make_Payment_button_after_entering_all_valid_details() {
		pay.click();
	}

	@Then("^A message 'Conference Room Booking successfully done!!!' should be displayed$")
	public void a_message_Conference_Room_Booking_successfully_done_should_be_displayed() {
		assertEquals("Conference Room Booking successfully done!!!", driver.switchTo().alert().getText());
		driver.switchTo().alert().dismiss();
	}
}

