package com.cucumber.CucumberTest;

public class Calculator {
	
	public int add(int a, int b) {
		System.out.println("add called from calculate");
		System.out.println(a+b);
		return a+b;
	}
}
