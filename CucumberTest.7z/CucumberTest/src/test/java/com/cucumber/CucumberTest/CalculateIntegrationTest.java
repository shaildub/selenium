package com.cucumber.CucumberTest;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions
(
	features = {"classpath:features/registration.feature"}		//	feature file path
	, plugin = {"pretty", "html:target/reports"}				//	output format (also available in xml, json), reports to be stored path
//	, glue = {"com.cucumber.CucumberTest.Calculator"}			//	main logic path
)

public class CalculateIntegrationTest {

}
