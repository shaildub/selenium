package com.capgemini.JUnitExample;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) {
        System.out.println( "Hello World!" );
    }

	public Object add(int i, int j) {
		System.out.println("add method called");
		System.out.println(i+j);
		return i+j;
	}

	public Object multiply(int i, int j) {
		System.out.println("multiply method called");
		System.out.println(i*j);
		return i*j;
	}

	
}
