package com.capgemini.JUnitExample;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class AppTest1 {
	
	@Before
	public void displaypre() {
		System.out.println("\n\n----!!Before hook!!----\n\n");
	}

	@After
	public void displaypost() {
		System.out.println("\n\n----!!After hook!!----\n\n");
	}
	
	@Test(timeout=1000000)
	public void ansTrue() {
		for(int i=0; i<1000000000; i++)
			System.out.println(i);
	}
}