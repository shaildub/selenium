package com.capgemini.JUnitExample;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import java.util.Scanner;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class AppTest2 {

	int a;
	
	@Before
	public void initial() {
		System.out.println("Enter a number:");
		Scanner s = new Scanner(System.in);
		a = s.nextInt();
		s.close();
	}
	
	@Test
	public void tested() {
		if(a==1)
		{
			System.out.println("In if statement");
			assertEquals(new com.capgemini.JUnitExample.App().add(1, 2), 3);
			fail("if failed");
		}
		else
		{
			System.out.println("In else statement");
			assertEquals(new com.capgemini.JUnitExample.App().multiply(a, 10), a*10 );
			fail("else failed");
		}
		
	}
	
	@After
	public void lasts() {
		System.out.println("\n...Testing is done!");
	}
	
}
